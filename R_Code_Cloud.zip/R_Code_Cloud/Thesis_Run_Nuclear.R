install.packages("rstudioapi", repos = "http://cran.us.r-project.org")
library(rstudioapi)

# file_name <- unlist(paste0(getSourceEditorContext()$path, "/")) 
# 
# short_file_name <- file_name[-length(file_name)]
# 
# file_location <- paste0(short_file_name, collapse = "/")
# 
# file_location <- paste0(file_location, "/")

setwd("/home/ubuntu/matthew_thesis/thesis_zip/R_Code_Cloud")

source("Thesis_Words.R")
source("Matthew_Thesis_Data_Collection_Master.R")

collect_tweets("nuclear", 168)
