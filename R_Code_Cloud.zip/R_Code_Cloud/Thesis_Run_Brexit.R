install.packages("rstudioapi", repos = "http://cran.us.r-project.org")
library(rstudioapi)

file_name <- unlist(str_split(getSourceEditorContext()$path, "/"))

short_file_name <- file_name[-length(file_name)]

file_location <- paste0(short_file_name, collapse = "/")

file_location <- paste0(file_location, "/")

setwd(file_location)

source("Thesis_Words.R")
source("Matthew_Thesis_Data_Collection_Master.R")

collect_tweets("brexit", 168)


