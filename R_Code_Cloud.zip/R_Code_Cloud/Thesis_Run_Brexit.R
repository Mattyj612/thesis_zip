install.packages("rstudioapi")
library(rstudioapi)

file_name <- unlist(str_split(getSourceEditorContext()$path, "/"))

short_file_name <- file_name[-length(file_name)]

file_location <- str_c(short_file_name, collapse = "/")

file_location <- str_c(file_location, "/")

setwd(file_location)

source("Thesis_Words.R")
source("Matthew_Thesis_Data_Collection_Master.R")

collect_tweets("brexit", 168)


