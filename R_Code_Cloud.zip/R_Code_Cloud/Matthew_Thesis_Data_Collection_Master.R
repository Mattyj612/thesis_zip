# Author: Matthew Jordan
# Big thanks to Michael Kearney, who developped the rtweet package
# Purpose: gather tweets about Brexit, nucelar power/energy, and trans rights

# Load necessary packages 

if (!requireNamespace("devtools", quietly = TRUE)) {
  install.packages("devtools")
}

# Install packages

devtools::install_github("mkearney/rtweet")
devtools::install_github("mkearney/tweetbotornot")
install.packages("dplyr")
install.packages("stringr")

library(rtweet)
library(tweetbotornot)
library(dplyr)
library(stringr)

# Get into the Twitter API (replace the dashes with your API info)
# You can do all of this at https://apps.twitter.com/

appname <- "Matthew_Jordan_Thesis"
key <- "gwDimUFtVVDzr0nnee3PBhf2u"
secret <- "XiyNGqMFT6GWtF8nIkmbSNXO3a5SAqBXSOfYpFTXtfxvAjXkQQ"
token <- "252827438-cBAVBf76GFWxwyJhknFZ6Z1Tqtd4n27YIptS2Tgp"
a_secret <- "uh4ZojHn1vGM8fqUWDG7nJ72rERwSVY54bfYigkj4KAmf"


create_token(
  app = appname,
  consumer_key = key,
  consumer_secret = secret,
  access_token = token,
  access_secret = a_secret
)


collect_tweets <- function(topic, number_of_hours) {
  for (run in 1:(number_of_hours/2)){
    topic_name = as.name(topic)
    file_title <- paste0(topic, "_tweets_", run)
    stream_tweets(
      q = words_data_frame %>% select(topic) %>% slice(1) %>% pull(),
      timeout = 60*60*2,
      parse = FALSE,
      file_name = file_title
    )
  }
}

