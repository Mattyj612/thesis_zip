nuclear_words <- "nuclear, nuclear energy, nuclear power, nukes, nuke, nucular, 
nuclear bomb, nuclear weapon, nuclear holocaust, #nuclear, #nuclearenergy, 
#nuclearpower, #nukes, #nuke, #nucular, #nuclearbomb, #nuclearweapon, 
#nuclearholocaust"

transgender_words <- "transgender, trans, LGBTQ, LGBTQ+, nonbinary, non-binary, 
non binary, genderqueer, transsexual, transphobia, transphobic, gender identity, 
gender expression, trans man, trans woman, gender dysphoria, #transgender, 
#trans, #LGBTQ, #LGBTQ+, #nonbinary, #genderqueer, #transsexual, #transphobia,
#transphobic, #genderidentity, #genderexpression, #transman, #transwoman, 
#genderdysphoria"

brexit_words <- "brexit, #brexit"

words_data_frame <- data_frame("nuclear" = nuclear_words,
                               "transgender" = transgender_words,
                               "brexit" = brexit_words)
